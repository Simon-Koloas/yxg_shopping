package ShoppingPlatform.view;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: Simon
 * @Date: 2023/07/17/15:22
 * @Description:
 */
public interface Home {
    /**
     * 用户注册
     */
    void register();

    /**
     * 用户登录
     */
    void login();
}
